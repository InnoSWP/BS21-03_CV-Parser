package com.example.first_val_product

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
